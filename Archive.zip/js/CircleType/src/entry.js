import CircleType from './class';

module.exports = CircleType;
