function initEditModal(albumDetails){

    $(".edit").on('click', function() {
      $('#addPlaylistForm').show();
      $('#formSongsContainer').hide();
    });


    $(".edit").on('click', function() {

        let album = null,
            id = $(this).attr('data-edit');

        $("#ModalAddPlayList").attr("data-action", "edit");
        $("#ModalAddPlayList").attr("data-id", id);

        for(let i in albumDetails) {
            if(albumDetails[i].id === $(this).attr('data-edit'))
                album = albumDetails[i];
        }

        $("#Playlist_Name").val(album.name);

        $("#Playlist_Url").val(album.image).change();


        var url = "api/playlist.php?type=songs&id=" + id;
        $.get(url, function(response) {
            var object = response.data.songs;

            object.forEach(function(song, key) {
                $(".newSong:nth-child(" + (key + 1) + ") .newSongUrl").val(song.url)
                $(".newSong:nth-child(" + (key + 1) + ") .newSongName").val(song.name)
              console.log("(:");
            })
        });





    });

    
    setplayListSubmitEventListener();

  function setplayListSubmitEventListener(){
      $('#formSongsContainer').on('submit', function (event) {
        if($("#ModalAddPlayList").attr("data-action") === "edit"){ 
        let id = $("#ModalAddPlayList").attr("data-id");
        event.preventDefault();
        var data = {
          name: $("#Playlist_Name").val(),
          image: $("#Playlist_Url").val(),
          songs: Array.prototype.slice.call($(".newSong")).map(song => ({
            name: $(".newSongName", song).val(), 
            url: $(".newSongUrl", song).val()
          })).filter(song => song.name && song.url)
        };
        $.post('api/playlist/'+id, data, () => {
            $.ajax({
                url: 'api/playlist/'+id+'/songs',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({songs: data.songs}),
                dataType: 'json',
                success: function (){
                    $("#ModalAddPlayList").modal('hide');
                    initAll();  
                }
            });
            
        });

        $.post('http://localhost:80/musicpro/api/playlist.php?type=songs&id='+id, JSON.stringify(data.songs), () => {
            $("#ModalAddPlayList").modal('hide');
            initAll();
        }, "json");
        
        
      }
    });
  }
}