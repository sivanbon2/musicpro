function initMusicPlayer() {

  $(".playImage").click(function(){
    $(".album").css({
      position:"relative", 
      top:"300px"
    });  
      $("#playerContainer").show();
      $( "ol li" ).addClass("songName");
      $(".songName").show();
      $(".songName").hide();

  });



}


function playMusic(id) {
  var url = "api/playlist.php?type=songs&id=" + id;
  $.get(url, function(response, songs) {
    console.log(response.data.songs);
    var object = response.data.songs;
  
    object.forEach(function(songs, album) {

      $('.songsList').append("<li>" +
        songs.name + "</li>");
      $(document).attr( 'title', songs.name );

      $('.songsList').on('click', function(){
        var pressedBtn = event.target;
       

          
         
      

      });



    })


    
    $("audio").attr("src", object[0].url);
  });
}













