function initAddModal(albumDetails){

	const addAlbumModal =  $("<div class=\"created-modal\">").load('html/addPopup.html', function(data){
		$('body').append(addAlbumModal);

		setPartOneValidation();

		updateImageUrl();

		setResetInputsListener();

		
  		setplayListSubmitEventListener();

      
      initEditModal(albumDetails);

      $("#add-new-playlist-button").on('click', function() {
        

        $('#formSongsContainer').hide();
        $('#addPlaylistForm').show();
        $("#ModalAddPlayList").attr("data-action", "add");
      });

	});



	function setPartOneValidation () {
		$('#addPlaylistForm').on('submit', function(event) {
			if ($(this).valid()) {
				$('#addPlaylistForm').hide();
				$('#formSongsContainer').show();

				event.preventDefault();
			}
		}).validate({
			rules: {
				Playlist_Url: {
					required: true,
					url: true
				}
			}
		});
	}


	//On the first modal insert URL and update the image
    function updateImageUrl(){
      $("#Playlist_Url").on('change', function(event) {

        let url = this.value;
        $("#thumbnail").attr("src", url);
      });
    }



    

       

    //Reset input Playlist Name and Playlist Url
    function setResetInputsListener(){
      $("#reset").on('click', function(event) {
        event.preventDefault();
        $("#Playlist_Name").val("");
        $("#Playlist_Url").val("");
        $("#thumbnail").attr("src", "https://vignette.wikia.nocookie.net/pandorahearts/images/7/70/No_image.jpg.png/revision/latest?cb=20121025132440&format=original");

      });
    }





  //adding new playlist
  function setplayListSubmitEventListener(){
    $('#formSongsContainer').on('submit', function (event) {
      if($("#ModalAddPlayList").attr("data-action") === "add"){ 
        event.preventDefault();
        var data = {
          name: $("#Playlist_Name").val(),
          image: $("#Playlist_Url").val(),
          songs: Array.prototype.slice.call($(".newSong")).map(song => ({
            name: $(".newSongName", song).val(), 
            url: $(".newSongUrl", song).val()
          })).filter(song => song.name && song.url)
        };
          $.post('api/playlist', data, () => {
          	$("#ModalAddPlayList").modal('hide')
    	      initAll();
          });
      }
    });
  }

        
}